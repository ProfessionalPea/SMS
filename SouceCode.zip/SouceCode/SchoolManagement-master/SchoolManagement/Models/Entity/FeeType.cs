﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models.Entity
{
    public class FeeType
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}