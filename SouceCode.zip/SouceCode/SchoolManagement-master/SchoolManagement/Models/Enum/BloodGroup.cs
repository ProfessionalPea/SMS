﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models.Enum
{
    public class BloodGroup
    {

    }
}